ace.define("ace/snippets/logtalk",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="logtalk"});                (function() {
                    ace.require(["ace/snippets/logtalk"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            