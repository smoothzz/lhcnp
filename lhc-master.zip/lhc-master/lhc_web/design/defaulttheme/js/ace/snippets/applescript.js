ace.define("ace/snippets/applescript",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="applescript"});                (function() {
                    ace.require(["ace/snippets/applescript"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            