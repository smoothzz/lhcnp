ace.define("ace/snippets/cobol",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="cobol"});                (function() {
                    ace.require(["ace/snippets/cobol"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            