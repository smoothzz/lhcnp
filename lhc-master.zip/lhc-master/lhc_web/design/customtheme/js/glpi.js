// Get form
lhc.glpiTicketRegister = function (chat_id) {
    //return lhc.revealModal({'url':WWW_DIR_JAVASCRIPT+'chat/glpiticket/' + chat_id});
	return lhc.revealModal({backdrop:true, 'url':WWW_DIR_JAVASCRIPT+'chat/glpiticket/' + chat_id})
};

// Create GLPI
lhc.glpiPostTicketRegister = function (chat_id, element) {

    $(element).attr('disabled', true);

    var data = {
        created: true,
        idchatfield: $('input[name="glpi_idchatfield"]').val(),
        type: $('select[name="glpi_type"]').val(),
        title: $('input[name="glpi_titulo_chat"]').val(),
        category: $('select[name="glpi_category"]').val(),
        content: $('textarea[name="chat-copy-messages"]').val()
    };

    if(data.type === ""|| data.category === "" || !data.content || !data.title  ) {
        $(element).removeAttr('disabled');
        return alert('Campos com * são obrigatórios.');
    }

    $('.fs12-modal-glpi').html('<div style="text-align: center;"><img src="/lhc/design/customtheme/images/general/loading.gif"></div>');
    
    $.post(WWW_DIR_JAVASCRIPT+'chat/glpiticket/' + chat_id, data).done(function (response) {

        //$('#myModal').html(response);
		$('#myModal').html(response).modal('show');

        $('#register').remove();

    }).fail(function (error) {

        if(error.responseJSON.message === 'ERROR_SESSION_TOKEN_INVALID') {
            lhc.glpiPostTicketRegister(chat_id);
        } else {
            alert('['+error.responseJSON.code+'] ' + error.responseJSON.message);
            $('#myModal').modal('toggle');
        }

    });
};

