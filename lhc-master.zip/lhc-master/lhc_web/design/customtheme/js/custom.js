var revealM = {

    initializeModal : function(selector) {

        var modelSelector = selector != undefined ? selector : 'myModal';

        if ($('#'+modelSelector).size() == 0) {

            var prependTo = null;
            if ($('#widget-layout').size() == 0) {
                prependTo = $('body');
            } else {
                prependTo = $('#widget-layout');
            };
            prependTo.prepend('<div id="'+modelSelector+'" style="padding-right:0px !important;" class="modal fade bs-example-modal-lg" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true"></div>');
        };

    },

    revealModal : function(params) {

        revealM.initializeModal('myModal');

        var modal_loading  = '<div class="modal-dialog modal-lg">';
            modal_loading += '<div class="modal-content">';
            modal_loading += '<div class="modal-body" style="text-align: center;">';
            modal_loading += '<img src="/lhc/design/customtheme/images/general/loading.gif">';
            modal_loading += '</div>';
            modal_loading += '</div>';
            modal_loading += '</div>';

        $('#myModal').html(modal_loading).modal('show');

        jQuery.get(params['url'], function(data) {

            if (typeof params['showcallback'] !== 'undefined') {
                $('#myModal').on('shown.bs.modal',params['showcallback']);
            }
            if (typeof params['hidecallback'] !== 'undefined') {
                $('#myModal').on('hide.bs.modal',params['hidecallback']);
            }
            $('#myModal').html(data);

        }).fail(function (error) {
            if(error.responseJSON.message === 'ERROR_SESSION_TOKEN_INVALID') {
                lhc.revealModal(params);
            } else {
                alert('Ocorreu um erro inesperado, favor tente novamente!');
                $('#myModal').modal('toggle');
            }
        });

    }
};