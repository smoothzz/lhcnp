<link rel="stylesheet"
      type="text/css"
      href="<?php echo erLhcoreClassDesign::designCSS('css/select2.css');?>" />