<script type="text/javascript"
        src="<?php echo erLhcoreClassDesign::designJS('js/custom.js');?>"></script>

<script type="text/javascript"
        src="<?php echo erLhcoreClassDesign::designJS('js/glpi.js');?>"></script>

<script type="text/javascript"
        src="<?php echo erLhcoreClassDesign::designJS('js/select2.full.js');?>"></script>
