<?php include(erLhcoreClassDesign::designtpl('modal/modal_header.tpl.php'));?>
<?php $messages = erLhcoreClassChat::getChatMessages($chat->id); ?>
    <?php
        
      // print_r($users);
    ?>
    <div class="content">
        <?php if(!isset($success)){ ?>
        <div class="col-sm-12">
            <!-- Profile -->
            <div class="card bg-primary">
                <div class="card-body profile-user-box">

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <div class="fotoEmpregadoCSC" style="width:100px; height: 100px; border-radius: 100%; background: url('<?php echo $requerente['foto']; ?>') no-repeat center center;background-size: contain;background-color: #FFF;padding: .25rem;"></div>
                                </div>
                                <div class="col">
                                    <div class="row">
                                        
                                            <h4 class="mt-1 mb-1 text-white">
                                                <?php echo $requerente['realname']." (".$requerente['name'].")"; ?>
                                            </h4>
                                        <div class="col-sm-8">
                                            <span class="font-13 text-white-50"> Função: </span>
                                            <span class="font-13 text-white"> <?php echo $requerente['comment']; ?> </span>
                                        </div>
                                        <div class="col-sm-4">
                                            <span class="font-13 text-white-50"> Status: </span>
                                            <span class="font-13 text-white"> <?php echo $requerente['is_active']? "Ativo":"inativo"; ?> </span>
                                        </div>
                                    </div>
                                    <div>
                                        
                                        <ul class="mb-0 list-inline text-light">
                                            <li class="list-inline-item me-3">
                                                <h5 class="mb-1"><?php echo $requerente['ch_novo']; ?></h5>
                                                <p class="mb-0 font-13 text-white-50">Novo</p>
                                            </li>
                                            <li class="list-inline-item me-3">
                                                <h5 class="mb-1"><?php echo $requerente['ch_atendimento']; ?></h5>
                                                <p class="mb-0 font-13 text-white-50">Atendimento</p>
                                            </li>
                                            <li class="list-inline-item">
                                                <h5 class="mb-1"><?php echo $requerente['ch_planejado']; ?></h5>
                                                <p class="mb-0 font-13 text-white-50">Planejados</p>
                                            </li>
                                            <li class="list-inline-item">
                                                <h5 class="mb-1"><?php echo $requerente['ch_pendente']; ?></h5>
                                                <p class="mb-0 font-13 text-white-50">Pendentes</p>
                                            </li>
                                            <li class="list-inline-item">
                                                <h5 class="mb-1"><?php echo $requerente['ch_fechado']; ?></h5>
                                                <p class="mb-0 font-13 text-white-50">Fechados</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- end col-->

                    </div> <!-- end row -->
                </div> <!-- end card-body/ profile-user-box-->
            </div><!--end profile/ card -->
        </div> <!-- end col-->
        <div class="col-sm-12">
            <hr/>
            <h4>Relação de Chamados abertos pelo requerente.</h4>
            <table cellpadding="0" cellspacing="0" class="table table-sm" width="100%">
                <thead>
                    <tr>
                        <th>Nº</th>
                        <th>Descrição</th>
                        <th>Status</th>
                        <th>data de abertura</th>

                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requerente['tickets']['data'] as $chm) : ?>
                        <?php if($chm[12]==1 || $chm[12]==2 || $chm[12]==3 || $chm[12]==4){ ?>
                            <?php 
                            $status = "";
                            switch ($chm[12]) {
                                case 1:
                                    $status = "Novo";
                                    break;
                                case 2:
                                    $status = "Em atendimento";
                                    break;
                                case 3:
                                    $status = "Planejado";
                                    break;
                                case 4:
                                    $status = "Pendente";
                                    break;
                                
                                default:
                                    $status = "";
                                    break;
                            } ?>
                    <tr>
                        <td><?php echo $chm[2]; ?></td>
                        <td><?php echo $chm[1]; ?></td>
                        <td><?php echo $status; ?></td>
                        <td><?php echo date_format(date_create($chm[15]), 'd/m/Y H:i:s'); ?></td>
                    </tr>
                        <?php } ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <hr/>
    <?php } ?>
        <div class="col">

            <?php if(isset($success)) : ?>
                <div style="text-align: center;" class="text-success">
                    <h4><?php echo $success; ?></h4>
                    <h4>Chamado: <a href="<?php echo $link; ?>" target="_blank"><?php echo $id; ?></a></h4>
                    <h4>Link: <a href="<?php echo $link; ?>" target="_blank"><?php echo $link; ?></a></h4>
                </div>
            <?php else : ?>
            <h4>Abertura de Chamado</h4>
            <p>Preencha todos os campo.</p>
                <form id="ticket-register-glpi needs-validation" novalidate>
                    <input type="hidden" name="glpi_idchatfield" value="<?php echo $chat->id; ?>">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="type">Título *</label>
                                <input class="form-control" type="text" name="glpi_titulo_chat" value="" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="type">Tipo *</label>
                                <select class="form-control" id="type" name="glpi_type">
                                    <option value="1" selected>Incidente</option>
                                    <option value="2">Requisição</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label for="itilcategories_id">Categoria *</label>
                            <select class="form-control" id="itilcategories_id" name="glpi_category">
                                <option value="">Selecione uma opção</option>
                                <?php foreach ($glpi_categories as $category) : ?>
                                    <option value="<?php echo $category['id'] ?>" <?=($category['id'] == 1513) ? 'selected' : ''; ?> >
                                        <?php echo $category['completename'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                     <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio0" value="0" onchange="copyMessageContent($(this))" checked>
                              <label class="form-check-label" for="inlineRadio1">Primeira Mensagem</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="1" onchange="copyMessageContent($(this))" >
                              <label class="form-check-label" for="inlineRadio1">Vazio</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="2" onchange="copyMessageContent($(this))">
                              <label class="form-check-label" for="inlineRadio2">Conversa</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="3" onchange="copyMessageContent($(this))">
                              <label class="form-check-label" for="inlineRadio3">Incluir mensagens do sistema</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="content">Descrição *</label>

                        <textarea name="chat-copy-messages" id="chat-copy-messages" rows="10" class="form-control"><?php echo htmlspecialchars($messages[0]['msg']); ?></textarea>
                    </div>
                </form>
                <script>
                    function copyMessageContent(inst) {
                        if (inst.is(':checked')) {
                            if(inst.val()=="0"){
                                $('#chat-copy-messages').val('<?php echo htmlspecialchars($messages[0]['msg']); ?>');
                            } else if(inst.val()=="1"){
                                 $('#chat-copy-messages').val('');
                            } else if(inst.val()=="2"){
                                $.getJSON(WWW_DIR_JAVASCRIPT  + 'chat/copymessages/<?php echo $chat->id?>/?system=false',function(data){
                                    $('#chat-copy-messages').val(data.result);
                                });
                            }else if(inst.val()=="3"){
                                $.getJSON(WWW_DIR_JAVASCRIPT  + 'chat/copymessages/<?php echo $chat->id?>/?system=true',function(data){
                                    $('#chat-copy-messages').val(data.result);
                                });
                            }
                        } else {
                            $('#chat-copy-messages').val('<?php echo htmlspecialchars($messages[0]['msg']); ?>');
                        }
                    }
                    </script>
            <?php endif; ?>

        </div>
    </div>
 <script>
    $('#itilcategories_id').select2();

</script> 
<?php include(erLhcoreClassDesign::designtpl('modal/modal_footer.tpl.php'));?>