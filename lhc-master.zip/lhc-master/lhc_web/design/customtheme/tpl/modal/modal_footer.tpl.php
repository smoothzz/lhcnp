	</div>
	<div class="modal-footer">
        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-sm" onclick="lhc.glpiPostTicketRegister(<?php echo $chat->id; ?>, this)" id="register">Registrar</button>
    </div>
</div>
</div>
<script>
    $('#itilcategories_id').select2();
</script>
